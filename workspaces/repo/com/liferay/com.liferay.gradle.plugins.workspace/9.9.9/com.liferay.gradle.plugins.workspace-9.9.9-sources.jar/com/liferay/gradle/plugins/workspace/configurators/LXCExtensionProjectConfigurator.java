package com.liferay.gradle.plugins.workspace.configurators;

import java.io.File;
import java.io.IOException;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.Collections;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Callable;

import org.gradle.api.Action;
import org.gradle.api.GradleException;
import org.gradle.api.Project;
import org.gradle.api.Task;
import org.gradle.api.artifacts.Configuration;
import org.gradle.api.artifacts.Dependency;
import org.gradle.api.artifacts.dsl.ArtifactHandler;
import org.gradle.api.file.ConfigurableFileCollection;
import org.gradle.api.file.CopySpec;
import org.gradle.api.file.DirectoryProperty;
import org.gradle.api.file.RegularFile;
import org.gradle.api.initialization.Settings;
import org.gradle.api.plugins.BasePlugin;
import org.gradle.api.plugins.BasePluginConvention;
import org.gradle.api.plugins.ExtensionAware;
import org.gradle.api.plugins.JavaPlugin;
import org.gradle.api.provider.Property;
import org.gradle.api.provider.Provider;
import org.gradle.api.tasks.Copy;
import org.gradle.api.tasks.Delete;
import org.gradle.api.tasks.TaskProvider;
import org.gradle.api.tasks.bundling.Zip;
import org.gradle.jvm.tasks.Jar;

import com.liferay.gradle.plugins.LiferayBasePlugin;
import com.liferay.gradle.plugins.LiferayOSGiPlugin;
import com.liferay.gradle.plugins.extensions.BundleExtension;
import com.liferay.gradle.plugins.util.BndUtil;
import com.liferay.gradle.plugins.workspace.WorkspaceExtension;
import com.liferay.gradle.plugins.workspace.WorkspacePlugin;
import com.liferay.gradle.plugins.workspace.internal.util.GradleUtil;
import com.liferay.gradle.util.Validator;

import aQute.lib.utf8properties.UTF8Properties;
import groovy.json.JsonSlurper;
import groovy.lang.Closure;

public class LXCExtensionProjectConfigurator extends BaseProjectConfigurator {

	public boolean isDefaultRepositoryEnabled() {
		return _defaultRepositoryEnabled;
	}
	
	protected static final String NAME = "lxc.extension";

	private static final boolean _DEFAULT_REPOSITORY_ENABLED = true;

	private final boolean _defaultRepositoryEnabled;
	
	public LXCExtensionProjectConfigurator(Settings settings) {
		super(settings);

		_defaultRepositoryEnabled = GradleUtil.getProperty(
				settings,
				WorkspacePlugin.PROPERTY_PREFIX + NAME +
					".default.repository.enabled",
				_DEFAULT_REPOSITORY_ENABLED);
	}

	@Override
	public String getName() {
		return "lxc-extension";
	}

	@Override
	public void apply(Project project) {
		File configJsonFile = project.file("configurator/config.json");
		
		Map<String, Object> configJsonMap = _getConfigJsonMap(
				configJsonFile);
		
		configJsonMap.entrySet().stream().forEach(entry -> {
			String name = _getConfigName(entry.getKey());
			String type = _getConfigType((Map<String, Object>) entry.getValue());
			String version = _getConfigVersion(entry.getKey());
			
			if ("favicon".equals(type) && "v1".equals(version)) {
				_applyFaviconV1(project, name, type);
			}
		});
	}

	private String _getConfigName(String key) {
		String[] segments = key.split("~");

		return segments[segments.length - 1];
	}

	private void _configureConfigurationDefault(Project project) {
		Configuration defaultConfiguration = GradleUtil.getConfiguration(
			project, Dependency.DEFAULT_CONFIGURATION);

		Configuration archivesConfiguration = GradleUtil.getConfiguration(
			project, Dependency.ARCHIVES_CONFIGURATION);

		defaultConfiguration.extendsFrom(archivesConfiguration);
	}

	private void _configureArtifacts(Project project, Jar jar) {
		ArtifactHandler artifacts = project.getArtifacts();

		artifacts.add(Dependency.ARCHIVES_CONFIGURATION, jar);
	}
	
	private void _configureTaskDeploy(Project project, Jar jar) {
		Copy copy = (Copy)GradleUtil.getTask(
			project, LiferayBasePlugin.DEPLOY_TASK_NAME);

		copy.dependsOn(BasePlugin.ASSEMBLE_TASK_NAME);
		copy.from(jar);
	}

	
	@SuppressWarnings({"serial", "unused"})
	private void _configureRootTaskDistBundle(Project project, Jar jar) {
		Task assembleTask = GradleUtil.getTask(
			project, BasePlugin.ASSEMBLE_TASK_NAME);

		Copy copy = (Copy)GradleUtil.getTask(
			project.getRootProject(),
			RootProjectConfigurator.DIST_BUNDLE_TASK_NAME);

		assembleTask.dependsOn(jar);

		copy.dependsOn(assembleTask);

		copy.into(
			"deploy",
			new Closure<Void>(project) {

				public void doCall(CopySpec copySpec) {
					Project project = assembleTask.getProject();

					Provider<RegularFile> fileProvider = jar.getArchiveFile();

					ConfigurableFileCollection configurableFileCollection =
						project.files(fileProvider);

					configurableFileCollection.builtBy(assembleTask);

					copySpec.from(fileProvider);
				}

			});
	}

	
	public static final String BUILD_FAVICON_TASK_NAME = "buildFavicon";
	
	private void _configureTaskClean(Project project) {
		Delete delete = (Delete)GradleUtil.getTask(
			project, BasePlugin.CLEAN_TASK_NAME);

		delete.delete("build", "dist");
	}

	@SuppressWarnings("serial")
	private Copy _addTaskBuildFavicon(Project project) {
		Copy copy = GradleUtil.addTask(
			project, BUILD_FAVICON_TASK_NAME, Copy.class);

		copy.setDescription("Assembles favicon.");
		copy.setGroup(BasePlugin.BUILD_GROUP);
		copy.into(
			new Callable<String>() {

				@Override
				public String call() throws Exception {
					return "";
				}

			},
			new Closure<Void>(copy) {

				@SuppressWarnings("unused")
				public void doCall(CopySpec copySpec) {
					CopySpec fromSrc = copySpec.from(project.file("src"));
					fromSrc.setIncludeEmptyDirs(false);
					fromSrc.include("*.ico");
				
				}

			});
		
		copy.into(
			new Callable<String>() {

				@Override
				public String call() throws Exception {
					return "configurator";
				}

			},
			new Closure<Void>(copy) {

				@SuppressWarnings("unused")
				public void doCall(CopySpec copySpec) {
					CopySpec fromSrc = copySpec.from(project.file("configurator"));
					fromSrc.setIncludeEmptyDirs(false);
					fromSrc.include("*.json");
				
				}

			});
		
		copy.setDestinationDir(project.getBuildDir());

		return copy;
	}
	
	private void _configureVersion(Project project) {
		project.setVersion("1.0");
	}
	

	private void _applyFaviconV1(Project project, String name, String type) {
		WorkspaceExtension workspaceExtension = GradleUtil.getExtension(
				(ExtensionAware)project.getGradle(), WorkspaceExtension.class);
		
		if (isDefaultRepositoryEnabled()) {
			GradleUtil.addDefaultRepositories(project);
		}
		
		GradleUtil.applyPlugin(project, LiferayOSGiPlugin.class);

		BasePluginConvention basePluginConvention = GradleUtil.getConvention(
				project, BasePluginConvention.class);

		basePluginConvention.setArchivesBaseName(type + "-" + name);
		
		_configureConfigurationDefault(project);
		_configureVersion(project);
		
		Copy faviconTask = _addTaskBuildFavicon(project);
				
		TaskProvider<Jar> jarTaskProvider = GradleUtil.getTaskProvider(
				project, JavaPlugin.JAR_TASK_NAME, Jar.class);

			jarTaskProvider.configure(
				new Action<Jar>() {

					@Override
					public void execute(Jar jar) {
						jar.dependsOn(faviconTask);

						DirectoryProperty destinationDirectoryProperty =
							jar.getDestinationDirectory();

						destinationDirectoryProperty.set(
							new File(project.getProjectDir(), "dist"));

						Property<String> archiveExtensionProperty =
							jar.getArchiveExtension();

						archiveExtensionProperty.set("zip");

						_configureArtifacts(project, jar);
						_configureTaskDeploy(project, jar);
						_configureRootTaskDistBundle(project, jar);
					}

				});

			_configureTaskClean(project);

			project.afterEvaluate(
				new Action<Project>() {

					@Override
					public void execute(Project project) {
						try {
							BundleExtension bundleExtension =
								BndUtil.getBundleExtension(project.getExtensions());

							bundleExtension.instruction(
								"faviconDockerFrom",
								"rotty3000/lxc-static-resources:latest");

							UTF8Properties properties = new UTF8Properties();

							properties.load(
								LXCExtensionProjectConfigurator.class.
									getResourceAsStream(
										"FaviconBundleInstructions.properties"));

							properties.forEach(
								(key, value) -> {
									String val = value.toString();

									bundleExtension.instruction(
										key.toString(),
										val.replace("\n", "\\n\\\n"));
								});
						}
						catch (IOException ioException) {
							throw new GradleException(
								"Error configuration Bundle Extension",
								ioException);
						}
					}

				});

			addTaskDockerDeploy(project, jarTaskProvider, workspaceExtension);
	}

	private String _getConfigVersion(String configEntry) {
		String[] segments = configEntry.split("\\.");
		
		return segments[segments.length - 2];
	}

	private String _getConfigType(Map<String, Object> configValue) {
		return configValue.get("type").toString();
	}

	@SuppressWarnings("unchecked")
	private Map<String, Object> _getConfigJsonMap(File configJsonFile) {
		if (!configJsonFile.exists()) {
			return Collections.emptyMap();
		}

		JsonSlurper jsonSlurper = new JsonSlurper();

		return (Map<String, Object>)jsonSlurper.parse(configJsonFile);
	}
	
	@Override
	protected Iterable<File> doGetProjectDirs(File rootDir) throws Exception {
		final Set<File> projectDirs = new HashSet<>();
		
		Files.walkFileTree(
			rootDir.toPath(),
			new SimpleFileVisitor<Path>() {

				@Override
				public FileVisitResult preVisitDirectory(
						Path dirPath, BasicFileAttributes basicFileAttributes)
					throws IOException {

					String dirName = String.valueOf(dirPath.getFileName());

					if (isExcludedDirName(dirName)) {
						return FileVisitResult.SKIP_SUBTREE;
					}

					Path configuratorPath = dirPath.resolve("configurator/config.json");
					
					if (Files.exists(configuratorPath)) {
						projectDirs.add(dirPath.toFile());

						return FileVisitResult.SKIP_SUBTREE;
					}

					return FileVisitResult.CONTINUE;
				}

			});

		return projectDirs;
	}

}
